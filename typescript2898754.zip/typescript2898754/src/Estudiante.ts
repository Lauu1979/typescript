export type Estudiante = {
    nombre :string;
    apellido :string;
    edad?:number | string;
    tipoIdentificacion:string;
    numueroIdentificacion:number | string;

}
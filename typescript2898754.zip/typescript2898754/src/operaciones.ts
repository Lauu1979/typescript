import { Estudiante } from "./Estudiante"
export const insertarEstudiante =
function(estudiante:Estudiante, arregloEstudiantes:Estudiante[])
{
    //Se utiliza el metodo push para agregar el nuevo estudiante
    arregloEstudiantes.push(estudiante);
}
export const ActualizarEstudiante = function (indice:number, nombre: string, apellido:string , listaEstudiante:Estudiante[])
     {
    //instrucciones poara actualizar el estudiante que se encuentre en el indice idicado en el parametro
    //listaEstudiante[indice]= 2,
}
export const BorrarEstudiante = function(indice:number ,listaEstudiante:Estudiante[])
{
//se utiliza splice para eliminar 
listaEstudiante.splice(indice,1);
}

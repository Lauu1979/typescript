//Funcion declaracion
import { Estudiante } from "./Estudiante";
/*export type tipo ={
    nombre:string;

}

function recorrerEstudiantes(arregloEstudiantes: Estudiante[]){
    arregloEstudiantes.forEach(function(elemento){
        console.log(elemento);
        console.log("--------")
    });

}
*/
//Funcion Expresion
/*const recorrerEstudiantes =function (arregloEstudiantes: Estudiante[]){
    arregloEstudiantes.forEach(function(elemento){
        console.log(elemento);
        console.log("--------")
    });

}*/
//Funcion flecha
const recorrerEstudiantes =function (arregloEstudiantes: Estudiante[]){
    arregloEstudiantes.forEach(function(elemento){
        console.log(elemento);
        console.log("--------")
    });
}
export default recorrerEstudiantes;
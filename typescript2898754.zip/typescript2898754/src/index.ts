import { Estudiante } from "./Estudiante";
//import recorrerEstudiantes from "./RecorrerEstudiantes";
import { insertarEstudiante ,ActualizarEstudiante,BorrarEstudiante} from "./operaciones";


//Definir objetos(literal) Estudiante
const estudiante1:Estudiante = {
    nombre:`Laura`, 
    apellido:`Bohorquez`,
    edad:18,
    tipoIdentificacion:`c.c`,
    numueroIdentificacion:1208272

}
const estudiante2:Estudiante={
    nombre:`Jhoan`,
    apellido:`Hernandez`,
    edad:`20`,
    tipoIdentificacion:`c.c`,
    numueroIdentificacion:221332

}
const estudiante3:Estudiante={
    nombre:`Jack`,
    apellido:`Roos`,
    tipoIdentificacion:`c.c`,
    numueroIdentificacion:656246

}
//Crear arreglo de estudiates
const listaEstudiante : Estudiante[] =[
    estudiante1, 
    estudiante2,
    estudiante3
]
//Operaciones con Arreglos
console.log("-----------------------")
console.log("Antes de insertar")
console.log(listaEstudiante)
insertarEstudiante(estudiante1,listaEstudiante);
console.log("-----------------------")
console.log("Despues de insertar")
console.log(listaEstudiante)

//ActualizarEstudiante(2, listaEstudiante,`lau`, `fuuy` );
//console.log(listaEstudiante)

console.log("-----------------------")
console.log("Antes de eliminar")
console.log(listaEstudiante)
BorrarEstudiante(1,listaEstudiante);
console.log("-----------------------")
console.log("Despues de eliminar ")
console.log(listaEstudiante)

